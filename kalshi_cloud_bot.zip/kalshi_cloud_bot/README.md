# Kalshi cloud bot

This project includes:
- a worker that watches multiple Kalshi markets over WebSockets
- entry logic: place a YES buy at 98 when the best YES bid is 98-99
- stop logic: if a filled YES position sees the best YES bid drop below 80, send a NO buy to flatten exposure
- a small FastAPI dashboard backed by SQLite for positions, fills, and PnL
- Railway-ready process definitions for a web service and a worker service

## Deploy on Railway

1. Create a new GitHub repo and upload these files.
2. In Railway, create a new project from that repo.
3. Add two services from the same repo:
   - `web` using the `web` process from `Procfile`
   - `worker` using the `worker` process from `Procfile`
4. Add the environment variables from `.env.example`.
5. Start in Kalshi demo mode first.

## Notes

- Put the private key into `KALSHI_PRIVATE_KEY_PEM` with literal `\n` line breaks, or convert it to a single-line environment variable safely before pasting.
- The dashboard reads from SQLite at `data/kalshi_bot.db`. On Railway, attach a volume if you want the DB to persist across redeploys.
- This code is a starter and should be hardened before live trading. Add daily loss limits, order-group protections, and alerting before production use.
